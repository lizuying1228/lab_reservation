from django.db import transaction
from students.models import Student
from rest_framework import serializers
from reservations.models import Reservation
from reservation_times.models import ReservationTime
from django.utils import timezone
import logging

logger = logging.getLogger(__name__)

@transaction.atomic
def delete_student(student_id, user_id):
    try:
        student = Student.objects.select_for_update().get(id = student_id)
    except Student.DoesNotExist:
        raise serializers.ValidationError({"Error": "该学生不存在"})

    if student.is_deleted:
        raise serializers.ValidationError({"Error": "该学生已删除"})

    active_statuses = [Reservation.StatusChoices.APPROVED, Reservation.StatusChoices.PENDING]
    reservationtime_ids = list(Reservation.objects.filter(student = student, status__in = active_statuses)
                               .values_list("reservationtime_id", flat=True).distinct())

    cancelled_count = 0
    if reservationtime_ids:
        reservationtimes = list(ReservationTime.objects.select_for_update()
                                .filter(id__in = reservationtime_ids).order_by("id"))
        reservationtime_map = {
            item.id: item for item in reservationtimes
        }

        reservations = list(Reservation.objects.select_for_update()
                            .filter(student = student, status__in = active_statuses).order_by("id"))

        approved_time_ids = set()

        for reservation in reservations:
            prev_status = reservation.status

            if prev_status == Reservation.StatusChoices.APPROVED:
                approved_time_ids.add(reservation.reservationtime_id)

            reservation.status = Reservation.StatusChoices.CANCELLED
            reservation.save(update_fields=["status"])
            cancelled_count += 1

            logger.info("Reservation cancelled successfully due to student deleted: "
                        "reservation_id=%s, student_id=%s, reservationtime_id=%s, "
                        "previous_status=%s, operator_id=%s", reservation.id, student.id,
                        reservation.reservationtime_id, prev_status, user_id)

        for reservationtime_id in approved_time_ids:
            reservationtime = reservationtime_map.get(reservationtime_id)
            if reservationtime is None:
                raise serializers.ValidationError({"Error": "预约时段不存在"})

            exists = Reservation.objects.filter(
                reservationtime = reservationtime,
                status = Reservation.StatusChoices.APPROVED
            ).exists()
            if not exists:
                reservationtime.status = ReservationTime.StatusChoices.AVAILABLE
                reservationtime.save(update_fields=["status"])

                logger.info("ReservationTime available successfully due to student deleted:"
                            "reservationtime_id=%s, student_id=%s, previous_status=%s, operator_id=%s",
                            reservationtime_id, student.id, ReservationTime.StatusChoices.OCCUPIED, user_id)

    student.is_deleted = True
    student.deleted_at = timezone.now()
    student.save(update_fields=["is_deleted", "deleted_at"])

    logger.info("Student deleted successfully:" \
                "student_id=%s, reservation_cancelled_count=%s, operator_id=%s", 
                student.id, cancelled_count, user_id)

    return student


            
        